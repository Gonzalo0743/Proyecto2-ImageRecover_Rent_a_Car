var searchData=
[
  ['genalgorithm_0',['genAlgorithm',['../classgen_algorithm.html#aa8601aaeaa738fd563efa7ae384c0322',1,'genAlgorithm']]],
  ['genome_1',['genome',['../classgenome.html#a8a367a136b7946dfa217da1e24d08a0b',1,'genome::genome()'],['../classgenome.html#a513afc2c9c702be2042a605504804cf4',1,'genome::genome(Mat baseDNA)']]],
  ['getgeneration_2',['getGeneration',['../classgen_algorithm.html#ac0a174252046f9ac4cb39b4e1e5023f0',1,'genAlgorithm']]],
  ['getvertice_3',['GetVertice',['../class_graph.html#a3fa9427174796e2f4f6a44448b6fe36d',1,'Graph']]]
];
