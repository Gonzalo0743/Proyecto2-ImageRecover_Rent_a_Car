var searchData=
[
  ['naturalselection_0',['naturalSelection',['../classgen_algorithm.html#a0a2592e447354a1e8b16d212061214bc',1,'genAlgorithm']]]
];
