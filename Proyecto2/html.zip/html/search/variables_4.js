var searchData=
[
  ['missingsindelen_0',['missingSindeLen',['../classgen_algorithm.html#a495f444e5c168462b4cbf56d2fb09836',1,'genAlgorithm']]],
  ['missingxpos_1',['missingXPos',['../classgen_algorithm.html#aace7284d1a4a660385e373961d329b24',1,'genAlgorithm']]]
];
