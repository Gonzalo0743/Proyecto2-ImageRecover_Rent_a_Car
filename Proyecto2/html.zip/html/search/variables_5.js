var searchData=
[
  ['population_0',['population',['../classgen_algorithm.html#a9b994170f1d825e19d4d8428186ab9ba',1,'genAlgorithm']]],
  ['populationsize_1',['populationSize',['../classgen_algorithm.html#af1c96544c22f8fb547771af045213987',1,'genAlgorithm']]]
];
