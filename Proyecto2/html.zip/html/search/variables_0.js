var searchData=
[
  ['dna_0',['DNA',['../classgenome.html#a6231daaaa1de3f1987b7c5af5c86b54a',1,'genome']]]
];
