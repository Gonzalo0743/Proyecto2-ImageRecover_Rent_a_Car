var searchData=
[
  ['vertice_0',['Vertice',['../class_vertice.html',1,'']]]
];
