var searchData=
[
  ['irwindow_0',['IRWindow',['../class_i_r_window.html',1,'']]]
];
