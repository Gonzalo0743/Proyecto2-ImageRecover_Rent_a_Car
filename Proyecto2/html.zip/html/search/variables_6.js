var searchData=
[
  ['secondhalf_0',['secondHalf',['../classgenome.html#ae4b4e2f1ebfeab4bf99ac212015cdd81',1,'genome']]]
];
