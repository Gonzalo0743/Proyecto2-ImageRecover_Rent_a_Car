var searchData=
[
  ['population_0',['population',['../classgen_algorithm.html#a9b994170f1d825e19d4d8428186ab9ba',1,'genAlgorithm']]],
  ['populationsize_1',['populationSize',['../classgen_algorithm.html#af1c96544c22f8fb547771af045213987',1,'genAlgorithm']]],
  ['primmejor_2',['PrimMejor',['../class_graph.html#a169f6a3a25b1db4664d3cc3a423d46e2',1,'Graph']]],
  ['printdna_3',['printDNA',['../classgenome.html#ac89c98125e9fc9e87d23f776f250f72b',1,'genome']]],
  ['printsplit_4',['printSplit',['../classgenome.html#aca5ef1733f2a1826836fbc3c66659d0b',1,'genome']]],
  ['profprimero_5',['ProfPrimero',['../class_graph.html#a2c20af425579e22679694215a1503501',1,'Graph']]],
  ['profrecorrido_6',['ProfRecorrido',['../class_graph.html#abd4a2fe118f9750ffd167f581853f5ab',1,'Graph']]]
];
